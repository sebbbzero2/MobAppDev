//
//  DetailViewController.swift
//  CampusCompanion
//
//  Created by TAN, SEBASTIEN LUIS on 9/12/26.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var messageLabel: UILabel!

    var studentName: String = ""
    var notificationsEnabled: Bool = false
    var selectedRole: String = ""
    var preferredEventDate: Date = Date()
    var numberOfGuests: Int = 1
    var announcement: CampusAnnouncement?

    override func viewDidLoad() {
        super.viewDidLoad()

        if let announcement = announcement {
            title = announcement.displayCategory
            messageLabel.text = """
            \(announcement.displayTitle)

            Category: \(announcement.displayCategory)
            Date: \(announcement.displayDate)
            Priority: \(announcement.displayPriority)
            Posted By: \(announcement.displayPostedBy)
            """
        } else {
            title = "Campus Events"

            let notificationStatus = notificationsEnabled ? "on" : "off"
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .medium
            dateFormatter.timeStyle = .none
            let eventDateText = dateFormatter.string(from: preferredEventDate)

            messageLabel.text = """
            Welcome, \(studentName)! (\(selectedRole))
            Notifications: \(notificationStatus).
            Event Date: \(eventDateText)
            Guests: \(numberOfGuests)
            """
        }
    }
}
