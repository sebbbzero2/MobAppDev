//
//  AnnouncementsViewController.swift
//  CampusCompanion
//

import UIKit
import CoreData

private enum SeedDefaultsKey {
    static let prefix = "CampusCompanion.initialAnnouncementsSeeded."
}

class AnnouncementsViewController: UITableViewController {

    private var announcements: [CampusAnnouncement] = []
    private var selectedAnnouncement: CampusAnnouncement?
    private var pendingErrorMessage: String?
    private weak var addAnnouncementAlert: UIAlertController?
    private weak var saveAnnouncementAction: UIAlertAction?

    private var appDelegate: AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }

    private var context: NSManagedObjectContext {
        return appDelegate.persistentContainer.viewContext
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Campus Announcements"
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 96
        tableView.tableFooterView = UIView()

        do {
            try seedInitialAnnouncementsIfNeeded()
            loadAnnouncements()
        } catch {
            context.rollback()
            showPersistenceError(error)
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let message = pendingErrorMessage {
            pendingErrorMessage = nil
            presentPersistenceError(message)
        }
    }

    @IBAction func addAnnouncementTapped(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(title: "New Announcement",
                                      message: "Enter a title and category.",
                                      preferredStyle: .alert)
        alert.addTextField { textField in
            textField.placeholder = "Title"
            textField.autocapitalizationType = .sentences
            textField.addTarget(self, action: #selector(self.announcementInputChanged(_:)),
                                for: .editingChanged)
        }
        alert.addTextField { textField in
            textField.placeholder = "Category"
            textField.autocapitalizationType = .words
            textField.addTarget(self, action: #selector(self.announcementInputChanged(_:)),
                                for: .editingChanged)
        }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))

        let saveAction = UIAlertAction(title: "Save", style: .default) { [weak self, weak alert] _ in
            guard let self = self,
                  let fields = alert?.textFields, fields.count == 2 else { return }
            let title = (fields[0].text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let category = (fields[1].text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            guard !title.isEmpty, !category.isEmpty else { return }

            let announcement = CampusAnnouncement(context: self.context)
            announcement.title = title
            announcement.category = category
            announcement.date = AnnouncementDate.storageString(from: Date())
            announcement.priority = "Normal"
            announcement.postedBy = category

            do {
                try self.context.save()
                self.loadAnnouncements()
            } catch {
                self.context.rollback()
                self.showPersistenceError(error)
            }
        }
        saveAction.isEnabled = false
        alert.addAction(saveAction)
        addAnnouncementAlert = alert
        saveAnnouncementAction = saveAction
        present(alert, animated: true)
    }

    @objc private func announcementInputChanged(_ sender: UITextField) {
        guard let fields = addAnnouncementAlert?.textFields, fields.count == 2 else { return }
        saveAnnouncementAction?.isEnabled = fields.allSatisfy {
            !($0.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
    }

    private func seedInitialAnnouncementsIfNeeded() throws {
        let coordinator = appDelegate.persistentContainer.persistentStoreCoordinator
        guard let store = coordinator.persistentStores.first,
              let storeID = coordinator.metadata(for: store)[NSStoreUUIDKey] as? String else {
            throw NSError(domain: "CampusCompanion.Persistence", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "The announcement store is unavailable."])
        }

        // Remember seeding per store, even if the user later deletes every row.
        // Reset Preferences removes only the three welcome keys, not this marker.
        let markerKey = SeedDefaultsKey.prefix + storeID
        guard !UserDefaults.standard.bool(forKey: markerKey) else { return }

        let request: NSFetchRequest<CampusAnnouncement> = CampusAnnouncement.fetchRequest()
        let existingCount = try context.count(for: request)
        if existingCount == 0 {
            for seed in AnnouncementSeedData.records {
                let announcement = CampusAnnouncement(context: context)
                announcement.title = seed.title
                announcement.date = seed.date
                announcement.category = seed.category
                announcement.priority = seed.priority
                announcement.postedBy = seed.postedBy
            }
            try appDelegate.saveContext()
        }

        // Set this only after a successful save or a confirmed nonempty store.
        UserDefaults.standard.set(true, forKey: markerKey)
    }

    private func loadAnnouncements() {
        let request: NSFetchRequest<CampusAnnouncement> = CampusAnnouncement.fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(key: "date", ascending: true),
                                   NSSortDescriptor(key: "title", ascending: true)]
        do {
            announcements = try context.fetch(request)
            tableView.reloadData()
            updateEmptyState()
        } catch {
            showPersistenceError(error)
        }
    }

    private func updateEmptyState() {
        guard announcements.isEmpty else {
            tableView.backgroundView = nil
            return
        }
        let label = UILabel()
        label.text = "No announcements yet.\nTap + to add one."
        label.textAlignment = .center
        label.numberOfLines = 0
        label.textColor = .secondaryLabel
        label.font = .preferredFont(forTextStyle: .body)
        tableView.backgroundView = label
    }

    private func showPersistenceError(_ error: Error) {
        presentPersistenceError(error.localizedDescription)
    }

    private func presentPersistenceError(_ message: String) {
        guard viewIfLoaded?.window != nil else {
            pendingErrorMessage = message
            return
        }
        let showAlert = { [weak self] in
            guard let self = self else { return }
            let alert = UIAlertController(title: "Announcement Storage",
                                          message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            self.present(alert, animated: true)
        }
        if let presented = presentedViewController {
            presented.dismiss(animated: true, completion: showAlert)
        } else {
            showAlert()
        }
    }

    override func tableView(_ tableView: UITableView,
                            numberOfRowsInSection section: Int) -> Int {
        return announcements.count
    }

    override func tableView(_ tableView: UITableView,
                            canEditRowAt indexPath: IndexPath) -> Bool {
        return announcements.indices.contains(indexPath.row)
    }

    override func tableView(_ tableView: UITableView,
                            commit editingStyle: UITableViewCell.EditingStyle,
                            forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete,
              announcements.indices.contains(indexPath.row) else { return }

        let announcement = announcements[indexPath.row]
        let deletedObjectID = announcement.objectID
        context.delete(announcement)
        do {
            try context.save()
            if selectedAnnouncement?.objectID == deletedObjectID {
                selectedAnnouncement = nil
            }
            announcements.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
            updateEmptyState()
        } catch {
            context.rollback()
            showPersistenceError(error)
        }
    }

    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(
            withIdentifier: "AnnouncementCell", for: indexPath
        ) as? AnnouncementCell else {
            return UITableViewCell()
        }
        cell.configure(with: announcements[indexPath.row])
        return cell
    }

    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        selectedAnnouncement = announcements[indexPath.row]
        performSegue(withIdentifier: "ShowAnnouncementDetailSegue", sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowAnnouncementDetailSegue",
              let destination = segue.destination as? DetailViewController,
              let announcement = selectedAnnouncement else { return }

        destination.announcement = announcement
    }
}
