#!/bin/bash
set -eu
project_dir="$(cd -- "$(dirname -- "$0")/.." && pwd)"
verification_temp="$(mktemp -d "${TMPDIR:-/tmp}/campus-dto-checks.XXXXXX")"
trap 'rm -rf "$verification_temp"' EXIT
xcrun swiftc -swift-version 5 -default-isolation MainActor -parse-as-library \
  "$project_dir/CampusCompanion/AnnouncementDTO.swift" \
  "$project_dir/Verification/DTOChecks.swift" \
  -o "$verification_temp/dto_checks"
"$verification_temp/dto_checks" "$project_dir/Verification/announcements_sample.json"
