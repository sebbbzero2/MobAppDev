import Foundation

@main
struct DTOChecks {
    enum CheckFailure: Error {
        case failed(String)
    }

    static func expect(_ condition: Bool, _ message: String) throws {
        if !condition { throw CheckFailure.failed(message) }
    }

    static func decode(_ json: String) throws -> [AnnouncementDTO] {
        return try JSONDecoder().decode([AnnouncementDTO].self, from: Data(json.utf8))
    }

    static func expectDecodeFailure(_ json: String) throws {
        do {
            _ = try decode(json)
        } catch is DecodingError {
            return
        }
        throw CheckFailure.failed("Invalid JSON shape unexpectedly decoded: \(json)")
    }

    static func main() throws {
        guard CommandLine.arguments.count == 2 else {
            throw CheckFailure.failed("Pass the sample JSON path.")
        }
        let data = try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]))
        // Exercise the actual app DTO on a background queue, with MainActor defaults enabled.
        let backgroundDecode: @Sendable () throws -> [AnnouncementDTO] = {
            try JSONDecoder().decode([AnnouncementDTO].self, from: data)
        }
        let rows = try DispatchQueue.global().sync(execute: backgroundDecode)
        try expect(rows.count == 3, "Expected three sample announcements.")
        try expect(rows[0].title == "Midterm Examination Schedule Released", "Title mismatch.")
        try expect(rows[0].date == "2026-08-15", "Date mismatch.")
        try expect(rows[0].category == "Academic", "Category mismatch.")
        let empty = try decode("[]")
        try expect(empty.isEmpty, "An empty feed is a valid authoritative list.")
        try expectDecodeFailure("not JSON")
        try expectDecodeFailure(#"{"title":"Test","date":"2026-01-01","category":"General"}"#)
        try expectDecodeFailure(#"[{"title":42,"date":"2026-01-01","category":"General"}]"#)
        try expectDecodeFailure(#"[{"date":"2026-01-01","category":"General"}]"#)
        try expectDecodeFailure(#"[{"title":"Test","date":2026,"category":"General"}]"#)
        try expectDecodeFailure(#"[{"title":"Test","date":"2026-01-01","category":null}]"#)
        try expect(rows[0].location == "Library, Rm 210", "Location mismatch.")
        try expect(rows[0].priorityLevel == "High", "Priority level mismatch.")
        let legacy = try decode(#"[{"title":"Test","date":"2026-01-01","category":"General"}]"#)
        try expect(legacy[0].location == "Not specified", "Missing location fallback failed.")
        try expect(legacy[0].priorityLevel == "Not specified", "Missing priority fallback failed.")
        let alias = try decode(#"[{"title":"Test","date":"2026-01-01","category":"General","location":"Hall","priority":"High"}]"#)
        try expect(alias[0].priorityLevel == "High", "priority alias failed.")
        let snake = try decode(#"[{"title":"Test","date":"2026-01-01","category":"General","location":"Hall","priority_level":"Medium"}]"#)
        try expect(snake[0].priorityLevel == "Medium", "priority_level alias failed.")
        try expectDecodeFailure(#"[{"title":"Test","date":"2026-01-01","category":"General","location":42}]"#)
        try expectDecodeFailure(#"[{"title":"Test","date":"2026-01-01","category":"General","priorityLevel":42}]"#)
        let canonical = try JSONSerialization.jsonObject(with: JSONEncoder().encode(alias)) as! [[String: Any]]
        try expect(canonical[0]["priorityLevel"] as? String == "High", "Encoding should use priorityLevel.")
        try expect(canonical[0]["priority"] == nil, "Encoding should not emit the alias key.")
        let encoded = try JSONEncoder().encode(rows)
        let roundTrip = try JSONDecoder().decode([AnnouncementDTO].self, from: encoded)
        try expect(roundTrip.count == rows.count, "Codable round trip lost records.")
        try expect(roundTrip[0].title == rows[0].title, "Codable round trip changed the title.")
        print("Passed DTO fixture, background decoding, invalid-input, and Codable round-trip checks.")
        print("These checks do not build or run UIKit, Core Data, or the live endpoint.")
    }
}
