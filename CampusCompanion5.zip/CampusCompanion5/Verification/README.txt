OFFLINE DTO CHECKS - RUN ON YOUR MAC

From the extracted project folder, run:
    bash Verification/run_dto_checks.sh

Requires Xcode with Swift 6.2 or later. This compiles the app's actual
AnnouncementDTO.swift with the same MainActor default as the project and
checks decoding on a background queue, valid records, empty arrays, invalid
field types, missing required keys, and Codable round trips.

These checks have NOT been executed in the delivery environment because
Swift/Xcode are unavailable. They do not test the live server, Core Data or UI.

announcements_sample.json is an illustrative test fixture based on the
handout's examples. It is NOT a captured server response and is NOT loaded
by the app as a fallback. A live Refresh always requests RemoteEndpoint.
