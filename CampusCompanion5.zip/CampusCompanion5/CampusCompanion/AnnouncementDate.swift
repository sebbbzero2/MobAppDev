//
//  AnnouncementDate.swift
//  CampusCompanion
//

import Foundation

enum AnnouncementDate {
    // ISO date strings sort chronologically in a Core Data String attribute.
    static func storageString(from date: Date) -> String {
        return storageFormatter.string(from: date)
    }

    static func displayString(from storedDate: String) -> String {
        guard let date = storageFormatter.date(from: storedDate) else {
            return storedDate
        }
        return DateFormatter.localizedString(from: date, dateStyle: .long, timeStyle: .none)
    }

    private static var storageFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.timeZone = .current
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.isLenient = false
        return formatter
    }
}
