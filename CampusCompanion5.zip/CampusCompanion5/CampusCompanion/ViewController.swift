//
//  ViewController.swift
//  CampusCompanion
//
//  Created by TAN, SEBASTIEN LUIS on 9/12/26.
//

import UIKit

private enum DefaultsKey {
    static let studentName = "studentName"
    static let notificationsEnabled = "notificationsEnabled"
    static let selectedRoleIndex = "selectedRoleIndex"
}

class ViewController: UIViewController {

    @IBOutlet weak var roleSegmentedControl: UISegmentedControl!
    @IBOutlet weak var notifySwitch: UISwitch!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var eventDatePicker: UIDatePicker!
    @IBOutlet weak var guestStepper: UIStepper!
    @IBOutlet weak var guestCountLabel: UILabel!

    @IBAction func exploreButtonTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder()
        let enteredName = nameTextField.text ?? ""

        UserDefaults.standard.set(enteredName, forKey: DefaultsKey.studentName)
        UserDefaults.standard.set(notifySwitch.isOn, forKey: DefaultsKey.notificationsEnabled)
        UserDefaults.standard.set(roleSegmentedControl.selectedSegmentIndex,
                                  forKey: DefaultsKey.selectedRoleIndex)

        performSegue(withIdentifier: "ShowDetailSegue", sender: self)
    }

    @IBAction func guestStepperChanged(_ sender: UIStepper) {
        updateGuestCountLabel()
    }

    @IBAction func resetPreferencesTapped(_ sender: UIButton) {
        view.endEditing(true)
        UserDefaults.standard.removeObject(forKey: DefaultsKey.studentName)
        UserDefaults.standard.removeObject(forKey: DefaultsKey.notificationsEnabled)
        UserDefaults.standard.removeObject(forKey: DefaultsKey.selectedRoleIndex)

        nameTextField.text = ""
        notifySwitch.isOn = false
        roleSegmentedControl.selectedSegmentIndex = 0
    }

    override internal func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowDetailSegue" else { return }
        guard let destination = segue.destination as? DetailViewController else { return }

        let enteredName = nameTextField.text ?? ""
        destination.studentName = enteredName.isEmpty ? "Student" : enteredName
        
        destination.notificationsEnabled = notifySwitch.isOn
        
        let selectedIndex = roleSegmentedControl.selectedSegmentIndex
        destination.selectedRole = roleSegmentedControl.titleForSegment(at: selectedIndex) ?? "Student"

        destination.preferredEventDate = eventDatePicker.date
        destination.numberOfGuests = Int(guestStepper.value)
    }
    @IBAction func getStartedButton(_ sender: UIButton) {
        subtitleLabel.text = "Let's get started!"
    }
    @IBOutlet weak var subtitleLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Start with today's date when the welcome screen first loads.
        eventDatePicker.preferredDatePickerStyle = .compact
        eventDatePicker.date = Date()
        updateGuestCountLabel()

        nameTextField.text = UserDefaults.standard.string(forKey: DefaultsKey.studentName) ?? ""
        notifySwitch.isOn = UserDefaults.standard.bool(forKey: DefaultsKey.notificationsEnabled)
        let savedRoleIndex = UserDefaults.standard.integer(forKey: DefaultsKey.selectedRoleIndex)
        let validRoleIndices = 0..<roleSegmentedControl.numberOfSegments
        roleSegmentedControl.selectedSegmentIndex = validRoleIndices.contains(savedRoleIndex)
            ? savedRoleIndex : 0
    }

    private func updateGuestCountLabel() {
        let count = Int(guestStepper.value)
        guestCountLabel.text = "Number of Guests: \(count)"
        guestStepper.accessibilityValue = "\(count)"
    }
}
