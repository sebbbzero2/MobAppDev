//
//  AnnouncementSeedData.swift
//  CampusCompanion
//

import Foundation

enum AnnouncementSeedData {
    // These records are inserted once. The list always reads from Core Data.
    static let records: [(title: String, date: String, category: String,
                          priority: String, postedBy: String)] = [
        ("Enrollment Period Extended", "2026-08-03", "Registrar",
         "Urgent", "Office of the Registrar"),
        ("Library Hours Extended for Finals", "2026-08-05", "Library",
         "Normal", "University Library"),
        ("Career Fair 2026", "2026-08-10", "Career Center",
         "Normal", "Career and Placement Office"),
        ("Student Council Elections", "2026-08-14", "Student Affairs",
         "Normal", "Office of Student Affairs"),
        ("Campus Wi-Fi Maintenance Notice", "2026-08-16", "IT Services",
         "Urgent", "IT Services"),
        ("Intramural Sports Sign-Up", "2026-08-20", "Athletics",
         "Normal", "Athletics Department")
    ]
}
