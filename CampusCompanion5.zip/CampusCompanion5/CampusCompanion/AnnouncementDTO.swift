//
//  AnnouncementDTO.swift
//  CampusCompanion
//

import Foundation

// A plain network value, separate from the Core Data-generated class.
// nonisolated allows background decoding with this project's MainActor default.
nonisolated struct AnnouncementDTO: Codable, Sendable {
    let title: String
    let date: String
    let category: String
    let location: String
    let priorityLevel: String

    private enum CodingKeys: String, CodingKey {
        case title, date, category, location, priorityLevel
        case priority
        case prioritySnakeCase = "priority_level"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        title = try values.decode(String.self, forKey: .title)
        date = try values.decode(String.self, forKey: .date)
        category = try values.decode(String.self, forKey: .category)
        // The handout does not publish a JSON example with the challenge keys.
        // Accept the common priority spellings and an older three-field feed.
        location = try values.decodeIfPresent(String.self, forKey: .location) ?? "Not specified"
        if let level = try values.decodeIfPresent(String.self, forKey: .priorityLevel) {
            priorityLevel = level
        } else if let level = try values.decodeIfPresent(String.self, forKey: .prioritySnakeCase) {
            priorityLevel = level
        } else {
            priorityLevel = try values.decodeIfPresent(String.self, forKey: .priority) ?? "Not specified"
        }
    }

    func encode(to encoder: Encoder) throws {
        var values = encoder.container(keyedBy: CodingKeys.self)
        try values.encode(title, forKey: .title)
        try values.encode(date, forKey: .date)
        try values.encode(category, forKey: .category)
        try values.encode(location, forKey: .location)
        try values.encode(priorityLevel, forKey: .priorityLevel)
    }
}
