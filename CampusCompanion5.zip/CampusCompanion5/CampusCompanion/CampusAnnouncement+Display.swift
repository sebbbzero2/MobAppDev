//
//  CampusAnnouncement+Display.swift
//  CampusCompanion
//

import CoreData

// Xcode generates CampusAnnouncement from the model's Class Definition setting.
// Required Core Data attributes can still have Optional Swift accessors.
extension CampusAnnouncement {
    var displayTitle: String {
        return Self.text(title, fallback: "Untitled Announcement")
    }

    var displayCategory: String {
        return Self.text(category, fallback: "Campus")
    }

    var displayDate: String {
        return AnnouncementDate.displayString(from: Self.text(date))
    }

    var displayPriority: String {
        return Self.text(priority, fallback: "Normal")
    }

    var displayLocation: String {
        return Self.text(location, fallback: "Not specified")
    }

    var displayPriorityLevel: String {
        // Existing Exercise 4 rows retain their original priority after migration.
        return Self.text(priorityLevel, fallback: displayPriority)
    }

    var displayPostedBy: String {
        return Self.text(postedBy, fallback: displayCategory)
    }

    private static func text(_ value: String?, fallback: String = "") -> String {
        guard let value = value, !value.isEmpty else { return fallback }
        return value
    }
}
