//
//  ViewController.swift
//  CampusCompanion
//
//  Created by TAN, SEBASTIEN LUIS on 9/12/26.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var roleSegmentedControl: UISegmentedControl!
    @IBOutlet weak var notifySwitch: UISwitch!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var eventDatePicker: UIDatePicker!
    @IBOutlet weak var guestStepper: UIStepper!
    @IBOutlet weak var guestCountLabel: UILabel!

    @IBAction func exploreButtonTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder()
        performSegue(withIdentifier: "ShowDetailSegue", sender: self)
    }

    @IBAction func guestStepperChanged(_ sender: UIStepper) {
        updateGuestCountLabel()
    }

    override internal func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowDetailSegue" else { return }
        guard let destination = segue.destination as? DetailViewController else { return }

        let enteredName = nameTextField.text ?? ""
        destination.studentName = enteredName.isEmpty ? "Student" : enteredName
        
        destination.notificationsEnabled = notifySwitch.isOn
        
        let selectedIndex = roleSegmentedControl.selectedSegmentIndex
        destination.selectedRole = roleSegmentedControl.titleForSegment(at: selectedIndex) ?? "Student"

        destination.preferredEventDate = eventDatePicker.date
        destination.numberOfGuests = Int(guestStepper.value)
    }
    @IBAction func getStartedButton(_ sender: UIButton) {
        subtitleLabel.text = "Let's get started!"
    }
    @IBOutlet weak var subtitleLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Start with today's date when the welcome screen first loads.
        eventDatePicker.preferredDatePickerStyle = .compact
        eventDatePicker.date = Date()
        updateGuestCountLabel()
    }

    private func updateGuestCountLabel() {
        let count = Int(guestStepper.value)
        guestCountLabel.text = "Number of Guests: \(count)"
        guestStepper.accessibilityValue = "\(count)"
    }
}
