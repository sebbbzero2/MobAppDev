//
//  AnnouncementCell.swift
//  CampusCompanion
//

import UIKit

class AnnouncementCell: UITableViewCell {

    @IBOutlet weak var categoryIconImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        titleLabel.font = UIFontMetrics(forTextStyle: .headline).scaledFont(
            for: .boldSystemFont(ofSize: 17)
        )
        dateLabel.font = UIFontMetrics(forTextStyle: .subheadline).scaledFont(
            for: .systemFont(ofSize: 14)
        )
        titleLabel.adjustsFontForContentSizeCategory = true
        dateLabel.adjustsFontForContentSizeCategory = true
        isAccessibilityElement = true
        accessibilityTraits = .button
    }

    func configure(with announcement: CampusAnnouncement) {
        let isUrgent = announcement.priority == "Urgent"

        // Assign both Urgent and Normal appearances on every configuration.
        // A recycled row must not keep the previous announcement's styling.
        titleLabel.text = announcement.title
        titleLabel.textColor = isUrgent ? .systemRed : .label
        let subtitle = "\(announcement.category) • \(announcement.date)"
        dateLabel.text = isUrgent ? "URGENT • \(subtitle)" : subtitle
        dateLabel.textColor = .secondaryLabel
        categoryIconImageView.image = UIImage(
            systemName: isUrgent ? "exclamationmark.triangle.fill" : "megaphone.fill"
        )
        categoryIconImageView.tintColor = isUrgent ? .systemRed : .systemBlue
        backgroundColor = isUrgent
            ? UIColor.systemRed.withAlphaComponent(0.08)
            : .systemBackground
        accessibilityLabel = "\(announcement.title), \(announcement.category), \(announcement.date), priority \(announcement.priority), posted by \(announcement.postedBy)"
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        backgroundColor = .systemBackground
        categoryIconImageView.tintColor = .systemBlue
        titleLabel.textColor = .label
        dateLabel.textColor = .secondaryLabel
        accessibilityLabel = nil
    }
}
